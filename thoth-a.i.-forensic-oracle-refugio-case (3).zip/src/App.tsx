import { useEffect, useState } from 'react';
import { REFUGIO_CASE } from './data/refugioCase';
import type { IdentityCase } from './data/refugioCase';
import { RefugioDashboard } from './components/forensic/RefugioDashboard';
import type { AccessMode } from './types/identityForensics';

export default function App() {
  const [caseRecord, setCaseRecord] = useState<IdentityCase>(REFUGIO_CASE);
  const [accessMode, setAccessMode] = useState<AccessMode>('public_analysis');

  useEffect(() => {
    fetch('/api/identity/cases/default')
      .then((response) => response.json())
      .then((payload) => {
        if (payload.caseRecord) {
          setCaseRecord(payload.caseRecord as IdentityCase);
        }
      })
      .catch(() => {
        setCaseRecord(REFUGIO_CASE);
      });
  }, []);

  return (
    <RefugioDashboard
      caseRecord={caseRecord}
      onCaseRecordChange={setCaseRecord}
      accessMode={accessMode}
      onAccessModeChange={setAccessMode}
    />
  );
}
