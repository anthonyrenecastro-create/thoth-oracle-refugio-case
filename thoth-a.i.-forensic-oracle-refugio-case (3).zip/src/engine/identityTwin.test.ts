import { describe, expect, it } from 'vitest';
import { REFUGIO_CASE } from '../data/refugioCase';
import { buildIdentityRunOutput, buildPublicBrief } from './identityTwin';
import { buildInformationGainAssessment, buildResidualCandidateSetAssessment, normalizeComparisonPriority } from './identityScoring';

describe('identity-first refugio flow', () => {
  it('loads the refugio case by default and preserves outside-candidate-set', () => {
    expect(REFUGIO_CASE.id).toContain('REFUGIO');
    expect(REFUGIO_CASE.outsideCurrentCandidateSet?.preserved).toBe(true);
    expect(REFUGIO_CASE.candidateRecords).toHaveLength(0);
  });

  it('does not declare an automatic winner and keeps human review required', () => {
    const output = buildIdentityRunOutput(REFUGIO_CASE, { fixtureMode: true });
    expect(output.recommendedNextAction.action).toContain('DNA');
    expect(output.humanReviewRequired).toBe(true);
    expect(output.identityCandidates.some((candidate) => candidate.disposition === 'confirmed_identification')).toBe(false);
  });

  it('produces qualitative and explainable scoring outputs for profiles and actions', () => {
    const priority = normalizeComparisonPriority(0.35, 0.2, 0.5, 0.4);
    const residual = buildResidualCandidateSetAssessment(REFUGIO_CASE, { namedCandidatesEntered: 0, verifiedExclusions: 0, recordCoverageStatus: 'partial' });
    const gain = buildInformationGainAssessment(0.95, 'very_high');
    expect(priority).toBeGreaterThan(0);
    expect(residual.residualWeight).toBeGreaterThan(0);
    expect(residual.interpretation).toContain('not_probability');
    expect(gain.qualitative).toBe('very_high');
    expect(gain.basis.length).toBeGreaterThan(0);
  });

  it('normalizes comparison priorities and removes restricted data in public brief', () => {
    const priority = normalizeComparisonPriority(0.35, 0.2, 0.5, 0.4);
    expect(priority).toBeGreaterThan(0);
    const brief = buildPublicBrief(REFUGIO_CASE, 'public_analysis');
    expect(brief.summary).toContain('Refugio County');
    expect(brief.summary).not.toContain('restricted');
  });

  it('exposes the augmentation metrics and critical unknowns in the case seed', () => {
    expect(REFUGIO_CASE.criticalUnknowns?.[0]?.title).toContain('DNA');
    expect(REFUGIO_CASE.coverageMetrics?.recordCoverageStatus).toBe('partial');
    expect(REFUGIO_CASE.recordSearchCoverage?.[0]?.scopeName).toContain('Refugio');
  });
});
