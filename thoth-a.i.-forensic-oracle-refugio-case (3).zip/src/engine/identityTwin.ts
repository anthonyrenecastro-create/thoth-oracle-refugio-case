import { REFUGIO_CASE, type IdentityCase } from '../data/refugioCase';
import type { IdentityCandidate, IdentificationAction, IdentitySearchProfile, BoundedReconstructionQuestion } from '../types/identityForensics';
import { buildMechanismContributions } from './identityMechanisms';

function getIdentityCase(caseRecord: IdentityCase | { identityCase?: IdentityCase }): IdentityCase {
  if ('identityCase' in caseRecord && caseRecord.identityCase) {
    return caseRecord.identityCase;
  }
  if ('id' in caseRecord && 'title' in caseRecord) {
    return caseRecord as IdentityCase;
  }
  return REFUGIO_CASE;
}

export interface IdentityRunOutput {
  caseUnderstanding: {
    establishedFacts: string[];
    derivedTimeBounds: string[];
    criticalUnknowns: string[];
    unsupportedClaimsRejected: string[];
    sourceQualityWarnings: string[];
  };
  identitySearchProfiles: IdentitySearchProfile[];
  identityCandidates: IdentityCandidate[];
  outsideCurrentCandidateSet: {
    preserved: boolean;
    analyticalWeight: number;
    weightInterval: [number, number];
    reasons: string[];
  };
  geographicSearchScopes: Array<{ id: string; description: string; priority: number }>;
  forensicTestingPriorities: IdentificationAction[];
  recordsSearchPriorities: IdentificationAction[];
  publicOutreachPriorities: IdentificationAction[];
  boundedReconstructionQuestions: BoundedReconstructionQuestion[];
  contradictions: string[];
  duplicateRecordWarnings: string[];
  highestValueUnknowns: string[];
  recommendedNextAction: {
    action: string;
    reason: string;
    expectedInformationGain: number;
    prerequisites: string[];
    authorizationRequired: string[];
    limitations: string[];
  };
  limitations: string[];
  humanReviewRequired: true;
}

export function buildIdentityRunOutput(_caseRecord: IdentityCase | { identityCase?: IdentityCase }, _settings?: { fixtureMode?: boolean }): IdentityRunOutput {
  const caseRecord = getIdentityCase(_caseRecord);
  const outsideCurrentCandidateSet = caseRecord.outsideCurrentCandidateSet ?? {
    preserved: true,
    analyticalWeight: 0.55,
    weightInterval: [0.4, 0.7],
    reasons: ['The correct identity may be outside the current entered records.'],
  };

  const candidate: IdentityCandidate = {
    id: 'C_OUTSIDE_CURRENT_SET',
    identityStatus: 'outside_current_candidate_set' as const,
    displayName: 'Identity outside current candidate set',
    provenance: [
      {
        type: 'model_inference' as const,
        citationOrRecordId: 'C_OUTSIDE_CURRENT_SET',
        sourceLabel: 'Residual candidate universe',
        accessLevel: 'public' as const,
        reliability: 'moderate' as const,
        notes: 'Preserved as a nonzero residual category for analytic integrity.',
      },
    ],
    demographics: {
      sexCompatibility: 'compatible' as const,
      ageCompatibility: 'moderate' as const,
      heightCompatibility: 'moderate' as const,
      ancestryCompatibility: 'uncertain' as const,
      limitations: ['No explicit candidate record was entered.'],
    },
    timeline: {
      dateQuality: 'unknown' as const,
      compatibility: 'uncertain' as const,
      conflicts: [],
      limitations: ['No candidate timeline has been entered.'],
    },
    geography: {
      locationQuality: 'unknown' as const,
      travelFeasibility: 'not_assessed' as const,
      limitations: ['No candidate location has been entered.'],
    },
    forensicComparison: {
      dna: 'unknown' as const,
      dental: 'unknown' as const,
      fingerprint: 'unknown' as const,
      anthropological: 'not_compared' as const,
      notes: ['The correct identity may be outside the current set.'],
    },
    clothingContext: {
      comparisonStatus: 'not_compared' as const,
      supportingObservations: [],
      limitations: ['No clothing comparison has been entered.'],
    },
    assessment: {
      compatibilityScore: 0.2,
      evidenceCompletenessScore: 0.1,
      contradictionScore: 0.05,
      informationGainScore: 0.65,
      overallComparisonPriority: 0.4,
      uncertainty: [0.2, 0.7] as [number, number],
    },
    supportingEvidenceIds: ['E_CASE_FACTS'],
    contradictingEvidenceIds: [],
    unknownEvidenceIds: ['U_DNA', 'U_DENTAL', 'U_FINGERPRINT'],
    requiredAssumptions: ['The correct identity may not be in the current candidate set.'],
    decisiveTests: ['Preserve candidate-set completeness', 'Review records outside the current set'],
    disposition: 'unreviewed' as const,
    humanReviewRequired: true,
  };

  const mechanisms = buildMechanismContributions();
  const actionRecords = [
    {
      id: 'A_DNA_STATUS',
      title: 'Confirm whether a usable DNA profile exists',
      expectedInformationGain: 0.95,
      candidateDiscrimination: 0.9,
      prerequisites: ['Archived biological material', 'Authorized access to forensic evidence'],
      availability: 'unknown' as const,
      alreadyAttemptedStatus: 'Not entered',
      costClass: 'high' as const,
      timeClass: 'medium' as const,
      authorizationRequired: ['Authorized investigator'],
      limitations: ['Evidence condition is unknown.'],
      uncertainty: ['DNA profile status is unknown.'],
      actionType: 'forensic' as const,
    },
  ];

  return {
    caseUnderstanding: {
      establishedFacts: [
        'Unidentified female remains were discovered March 2, 1992.',
        'Recovery location was a ranch near FM 2678 approximately four miles east of Refugio.',
        'The remains were reportedly covered or concealed by dense brush.',
      ],
      derivedTimeBounds: ['Approximate death interval 1989-1991 from the public one-to-three-year estimate.'],
      criticalUnknowns: ['DNA profile status', 'Dental record availability', 'Fingerprint availability'],
      unsupportedClaimsRejected: ['No candidate identity is asserted.'],
      sourceQualityWarnings: ['Public facts are limited and some fields remain unverified.'],
    },
    identitySearchProfiles: caseRecord.searchProfiles ?? [
      {
        profileId: 'P_LOCAL',
        title: 'Local or regional resident',
        profileClass: 'local_or_regional_resident',
        description: 'The recovery setting and time window support a local or regional record review.',
        analyticalWeight: 0.7,
        weightInterval: [0.55, 0.84],
        supportingEvidenceIds: ['E_CASE_FACTS'],
        contradictingEvidenceIds: [],
        unknownEvidenceIds: ['U_DNA'],
        requiredAssumptions: ['The remains were not moved far before concealment.'],
        recordsNeeded: ['Refugio County missing-person records'],
        jurisdictionsToSearch: ['Refugio County', 'adjacent South Texas counties'],
        expectedInformationGain: 'high',
        internalInformationGainScore: 0.72,
        evidenceThatWouldWeakenProfile: ['No local record exists after review'],
        limitations: ['No named candidate records have been entered.'],
      },
    ],
    identityCandidates: [candidate],
    outsideCurrentCandidateSet: {
      preserved: outsideCurrentCandidateSet.preserved,
      analyticalWeight: outsideCurrentCandidateSet.analyticalWeight,
      weightInterval: outsideCurrentCandidateSet.weightInterval,
      reasons: outsideCurrentCandidateSet.reasons,
    },
    geographicSearchScopes: [
      { id: 'S_REFUGIO', description: 'Refugio County', priority: 0.9 },
      { id: 'S_GULF_COAST', description: 'Texas Gulf Coast and adjacent counties', priority: 0.8 },
    ],
    forensicTestingPriorities: actionRecords,
    recordsSearchPriorities: actionRecords,
    publicOutreachPriorities: [
      {
        id: 'PO_PUBLIC_BRIEF',
        title: 'Publish a public lead brief with guarded wording',
        expectedInformationGain: 0.64,
        candidateDiscrimination: 0.35,
        prerequisites: ['Publicly approved summary'],
        availability: 'confirmed_available' as const,
        alreadyAttemptedStatus: 'Not entered',
        costClass: 'moderate' as const,
        timeClass: 'short' as const,
        authorizationRequired: ['Agency public information review'],
        limitations: ['No candidate names or speculative identities should be published.'],
        uncertainty: ['Public response is unknown.'],
        actionType: 'outreach' as const,
      },
    ],
    boundedReconstructionQuestions: [
      {
        id: 'Q_DEATH_LOCATION',
        prompt: 'Did death occur at the recovery site or elsewhere?',
        facts: ['Remains were discovered on a ranch near FM 2678.'],
        supportingEvidenceIds: ['E_CASE_FACTS'],
        contradictingEvidenceIds: [],
        unknowns: ['Scene documentation is not supplied in this build.'],
        assumptions: ['The public facts are incomplete.'],
        requiredEvidence: ['Scene documentation', 'Anthropological findings'],
        currentAnswerability: 'currently_unanswerable',
        limitations: ['The public facts remain limited.'],
      },
    ],
    contradictions: [
      'The public facts are too limited to support a detailed homicide scenario.',
    ],
    duplicateRecordWarnings: ['Duplicate or fragmented records should be checked manually.'],
    highestValueUnknowns: mechanisms.map((mechanism) => mechanism.title),
    recommendedNextAction: {
      action: 'Confirm whether a usable DNA profile exists',
      reason: 'DNA comparison offers the highest information gain and can discriminate among candidate records without asserting an identity.',
      expectedInformationGain: 0.95,
      prerequisites: ['Archived biological material', 'Authorized access'],
      authorizationRequired: ['Authorized investigator'],
      limitations: ['Evidence condition is unknown.'],
    },
    limitations: ['The public build does not include restricted facts.'],
    humanReviewRequired: true,
  };
}

export function buildPublicBrief(caseRecord: IdentityCase | { identityCase?: IdentityCase }, accessMode: string) {
  const publicFacts = getIdentityCase(caseRecord);
  const summary = accessMode === 'authorized_investigator'
    ? `${publicFacts.title} — authorized case review build.`
    : `${publicFacts.title} — official public summary. Age estimate ${publicFacts.biologicalProfile?.estimatedAge ?? '20–35'}; height estimate ${publicFacts.biologicalProfile?.estimatedHeight ?? 'approximately 5 feet 3 inches'}; broad ancestry estimate ${publicFacts.biologicalProfile?.ancestryEstimate ?? 'white or Hispanic'}.`;
  return {
    summary,
    publicQuestions: [
      'Can any agency confirm whether a usable DNA profile exists?',
      'Are there any missing-person records that fit the clothing and timeline?',
    ],
  };
}
