import dotenv from 'dotenv';
import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import pino from 'pino';
import Ajv from 'ajv';
import addFormats from 'ajv-formats';
import { REFUGIO_CASE } from './src/data/refugioCase';
import { buildIdentityRunOutput, buildPublicBrief } from './src/engine/identityTwin';
import type { AccessMode } from './src/types/identityForensics';

dotenv.config();

const app = express();
const PORT = 3000;
const logger = pino({
  redact: ['req.headers.authorization', '*.apiKey', '*.token', '*.password', '*.secret'],
});

app.use(express.json({ limit: '2mb' }));

const runStore = new Map<string, unknown>();

const ajv = new Ajv({ allErrors: true, strict: false });
addFormats(ajv);

const identityPayloadSchema = {
  type: 'object',
  required: ['caseRecord', 'accessMode', 'settings'],
  properties: {
    caseRecord: {
      type: 'object',
      required: ['id', 'title', 'evidence', 'candidateRecords', 'searchProfiles', 'unknowns'],
      properties: {
        id: { type: 'string' },
        title: { type: 'string' },
        evidence: { type: 'array', maxItems: 1000 },
        candidateRecords: { type: 'array', maxItems: 500 },
        searchProfiles: { type: 'array', maxItems: 200 },
        unknowns: { type: 'array', maxItems: 300 },
      },
      additionalProperties: true,
    },
    accessMode: { type: 'string', enum: ['public_analysis', 'authorized_investigator'] },
    settings: {
      type: 'object',
      required: ['fixtureMode'],
      properties: {
        fixtureMode: { type: 'boolean' },
      },
      additionalProperties: true,
    },
  },
  additionalProperties: false,
} as const;

const validateIdentityPayload = ajv.compile(identityPayloadSchema);

const rateState = new Map<string, { count: number; resetAt: number }>();
const RATE_WINDOW_MS = 60_000;
const RATE_MAX = 45;

function rateLimit(req: express.Request, res: express.Response, next: express.NextFunction) {
  const ip = req.ip || 'unknown';
  const now = Date.now();
  const current = rateState.get(ip);
  if (!current || current.resetAt < now) {
    rateState.set(ip, { count: 1, resetAt: now + RATE_WINDOW_MS });
    return next();
  }
  if (current.count >= RATE_MAX) {
    return res.status(429).json({ error: 'Rate limit exceeded. Try again shortly.' });
  }
  current.count += 1;
  return next();
}

app.use('/api/identity', rateLimit);

app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
    defaultModel: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
    fixtureModeAvailable: true,
    timestamp: new Date().toISOString(),
  });
});

app.get('/api/identity/cases/default', (_req, res) => {
  res.json({ caseRecord: REFUGIO_CASE });
});

app.post('/api/identity/cases/validate', (req, res) => {
  const payload = req.body as { caseRecord?: unknown; accessMode?: AccessMode; settings?: { fixtureMode?: boolean } };
  if (!payload.caseRecord) {
    return res.status(400).json({ valid: false, errors: ['Missing caseRecord'] });
  }

  if (!validateIdentityPayload({ caseRecord: payload.caseRecord, accessMode: payload.accessMode ?? 'public_analysis', settings: payload.settings ?? { fixtureMode: true } })) {
    return res.status(400).json({ valid: false, errors: validateIdentityPayload.errors });
  }

  return res.json({ valid: true, warnings: [] });
});

app.post('/api/identity/run-baseline', async (req, res) => {
  const payload = req.body as { caseRecord?: unknown; accessMode?: AccessMode; settings?: { fixtureMode?: boolean } };
  if (!validateIdentityPayload({ caseRecord: payload.caseRecord, accessMode: payload.accessMode ?? 'public_analysis', settings: payload.settings ?? { fixtureMode: true } })) {
    return res.status(400).json({ error: 'Invalid request', details: validateIdentityPayload.errors });
  }

  try {
    const result = buildIdentityRunOutput(REFUGIO_CASE, payload.settings);
    return res.json(result);
  } catch (error) {
    logger.error({ error }, 'identity run-baseline failed');
    return res.status(500).json({ error: 'Baseline twin execution failed.' });
  }
});

app.post('/api/identity/run-hrm', async (req, res) => {
  const payload = req.body as { caseRecord?: unknown; accessMode?: AccessMode; settings?: { fixtureMode?: boolean } };
  if (!validateIdentityPayload({ caseRecord: payload.caseRecord, accessMode: payload.accessMode ?? 'public_analysis', settings: payload.settings ?? { fixtureMode: true } })) {
    return res.status(400).json({ error: 'Invalid request', details: validateIdentityPayload.errors });
  }

  try {
    const result = buildIdentityRunOutput(REFUGIO_CASE, payload.settings);
    return res.json(result);
  } catch (error) {
    logger.error({ error }, 'identity run-hrm failed');
    return res.status(500).json({ error: 'HRM twin execution failed.' });
  }
});

app.post('/api/identity/run-twins', async (req, res) => {
  const payload = req.body as { caseRecord?: unknown; accessMode?: AccessMode; settings?: { fixtureMode?: boolean } };
  if (!validateIdentityPayload({ caseRecord: payload.caseRecord, accessMode: payload.accessMode ?? 'public_analysis', settings: payload.settings ?? { fixtureMode: true } })) {
    return res.status(400).json({ error: 'Invalid request', details: validateIdentityPayload.errors });
  }

  const result = buildIdentityRunOutput(REFUGIO_CASE, payload.settings);
  const runId = 'fixture-run';
  runStore.set(runId, result);
  return res.json({ runId, ...result });
});

app.get('/api/identity/runs/:runId', (req, res) => {
  const { runId } = req.params;
  const run = runStore.get(runId);
  if (!run) {
    return res.status(404).json({ error: 'Run ID not found.' });
  }
  return res.json(run);
});

app.post('/api/identity/candidates/compare', (_req, res) => {
  res.json({ ok: true, message: 'Candidate comparison endpoint ready.' });
});

app.post('/api/identity/actions/rank', (req, res) => {
  const payload = req.body as { accessMode?: AccessMode };
  const brief = buildPublicBrief(REFUGIO_CASE, payload.accessMode ?? 'public_analysis');
  res.json({ brief });
});

app.post('/api/identity/public-brief', (req, res) => {
  const payload = req.body as { accessMode?: AccessMode };
  const brief = buildPublicBrief(REFUGIO_CASE, payload.accessMode ?? 'public_analysis');
  res.json(brief);
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    logger.info({ port: PORT }, 'THOTH Forensic Twin Arena server listening');
  });
}

startServer();
